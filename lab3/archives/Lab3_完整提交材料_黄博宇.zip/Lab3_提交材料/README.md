# Lab3 提交材料导航

| 项目 | 文件或说明 |
|---|---|
| 学生 | 黄博宇，24020036026，中外计科一班，第8组 |
| 综合报告 | [10页PDF](Lab3_实验报告_黄博宇.pdf) / [可编辑原稿](Lab3_实验报告_可编辑原稿.md) |
| D1 | [deliverable_1.txt](deliverable_1.txt)，四元数转换五问 |
| D2 | [deliverable_2.pdf](deliverable_2.pdf)，矩阵秩分析与阻力补偿推导 |
| 团队代码 | [controller_pkg](controller_pkg/)，完整包，圆轨迹模式 |
| 实测参数 | kx=2、kv=3、kr=3、komega=1 |
| 分析材料 | [analysis](analysis/)，指标、CSV、图像与复算脚本 |
| 原始截图 | [screenshots](screenshots/)，8张实际截图 |
| 复习与操作 | [操作与复习](操作与复习/)，启动流程和速记 |
| 实测结论 | 44.64秒、约3.55圈；位置RMSE约10.52厘米；yaw RMSE约9.52度 |
| 待补交付 | 视频上传Drive/Dropbox，公开链接写入rviz_drone_flight.txt |
| 源码整理 | 仅将原包的默认增益统一为实际启动值；用户原包另行保留，算法未变 |
| 编译范围 | 用户已成功编译和飞行；默认值整理后仍应在Ubuntu catkin build，本机没有ROS |
| 视频与bag | https://github.com/hbyhby123/vnav-personal/tree/master/lab3/evidence/circle_20261021_081755 |
| 最新导航 | https://github.com/hbyhby123/vnav-personal/tree/master/lab3 |
| 正式提交 | 个人与团队材料按老师指定仓库提交；本包不是提交回执 |
